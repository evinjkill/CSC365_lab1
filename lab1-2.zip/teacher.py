# Evin Killian, Tyler Campanile

class Teacher:
    def __init__(self, last, first, classroom, grade=-1):
        self.last = last
        self.first = first
        self.grade = grade
        self.classroom = classroom
        
        
