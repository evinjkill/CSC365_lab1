# Evin Killian, Tyler Campanile

class Student:
    def __init__(self, last, first, grade, classroom, bus, gpa, t_last="", t_first=""):
        self.last = last
        self.first = first
        self.grade = grade
        self.classroom = classroom
        self.bus = bus
        self.gpa = gpa
        self.t_last = t_last
        self.t_first = t_first
        
        
